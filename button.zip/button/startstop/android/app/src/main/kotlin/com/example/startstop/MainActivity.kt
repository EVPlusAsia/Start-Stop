package com.example.startstop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
